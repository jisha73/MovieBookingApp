package com.theatre.dao;

import javax.persistence.Query;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.theatre.entity.TheatreEntity;
import com.theatre.model.Theatre;

@Repository(value="theatreDAO")

public class TheatreDAOImpl implements TheatreDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	//========================================ADD THEATRE=========================================//
	@Override
	public String addTheatre(Theatre theatre) throws Exception{
		
			TheatreEntity theatreEntity= entityManager.find(TheatreEntity.class, theatre.getTheatreName());
			if(	theatreEntity!=null) {
				return null;}
			TheatreEntity theatreEntity1= new TheatreEntity();
			theatreEntity1.setTheatreName( theatre.getTheatreName());
			theatreEntity1.setLocation(theatre.getLocation());
			theatreEntity1.setSeatingCapacity(theatre.getSeatingCapacity());
			theatreEntity1.setPrice(theatre.getPrice());
			entityManager.persist(theatreEntity1);
			return theatre.getTheatreName();
	
		
	}
	
//===================================================UPDATE THEATRE==============================//
	@Override
	public String updateTheatre(Theatre theatre) throws Exception{

			TheatreEntity theatreEntity= entityManager.find(TheatreEntity.class, theatre.getTheatreName());
			if(	theatreEntity==null)  {
				return null;
			}
			
			theatreEntity.setLocation(theatre.getLocation());
			theatreEntity.setPrice(theatre.getPrice());
			theatreEntity.setSeatingCapacity(theatre.getSeatingCapacity());
		  	Query query = entityManager.createQuery("select a from TheatreEntity a where a.theatreName=:theatreName");
				query.setParameter("theatreName",theatreEntity.getTheatreName());
				List<TheatreEntity > theartrelist=query.getResultList();
				for(TheatreEntity  a: theartrelist) {
				
					a.setLocation(theatreEntity.getLocation());
					a.setPrice(theatreEntity .getPrice());
					a.setSeatingCapacity(theatreEntity.getSeatingCapacity());
					return theatre.getTheatreName();
				}return null;
	}
			


		
		
		//=============================DELETE THEATRE=============================//
	@Override
	public String deleteUser(Theatre theatre) throws Exception {
		
			TheatreEntity theatreEntity= entityManager.find(TheatreEntity.class, theatre.getTheatreName());
			if(	theatreEntity!=null)  {
				Query query = entityManager.createQuery("select a from TheatreEntity a where a.theatreName=:theatreName");
				query.setParameter("theatreName",theatreEntity.getTheatreName());
				List<TheatreEntity > theatrelist=query.getResultList();
				for(TheatreEntity  a: theatrelist) {
					a.setTheatreName(null);
					a.setLocation(null);
					a.setPrice(null);
					a.setSeatingCapacity(null);
				}
					
				entityManager.remove(theatreEntity);
				return theatre.getTheatreName();
				}
				return null;
		
		}
	
	     //==============================GET THEATRE LIST=============================================//
	@Override
	public List<Theatre> getAllTheatreDetails() throws Exception{
	
			List<Theatre> finaltheatre = new ArrayList<Theatre>();
			Query query = entityManager.createQuery("select u from TheatreEntity u");
			List<TheatreEntity> theatreList = query.getResultList();
			if(theatreList != null) {
				for(TheatreEntity theatreEntity: theatreList) {
					Theatre theatre = new Theatre();
					theatre.setTheatreName(theatreEntity.getTheatreName());
					theatre.setLocation(theatreEntity.getLocation());
					theatre.setSeatingCapacity(theatreEntity.getSeatingCapacity());
					theatre.setPrice(theatreEntity.getPrice());
					finaltheatre.add(theatre);
				}
			}return finaltheatre;
		
	}

		
		
		
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
