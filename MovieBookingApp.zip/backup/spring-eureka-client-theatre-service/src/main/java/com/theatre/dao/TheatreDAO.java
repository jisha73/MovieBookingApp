package com.theatre.dao;

import com.theatre.model.Theatre;


import java.util.List;


public interface TheatreDAO {


	public String addTheatre(Theatre theatre) throws Exception;
	public String updateTheatre(Theatre theatre) throws Exception;
	public String deleteUser(Theatre theatre) throws Exception ;
	public List<Theatre> getAllTheatreDetails() throws Exception;

}
