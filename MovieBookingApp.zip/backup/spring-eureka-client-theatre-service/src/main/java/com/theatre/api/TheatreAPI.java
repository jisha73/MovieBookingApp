package com.theatre.api;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.theatre.model.Theatre;
import com.theatre.service.TheatreService;


@RestController
@CrossOrigin
@RequestMapping(value="/theatreDetails")
public class TheatreAPI {
	
	@Autowired
	private TheatreService theatreService;
	@Autowired
	private Environment env;
	
	//=================ADD THEATRE=============================//
	@PostMapping(path="/addTheatre")	
	public ResponseEntity<String> addTheatre(@RequestBody Theatre theatre) throws Exception{
		
		
		try {
String message=theatreService.addTheatre(theatre);
			
			String successmsg=message+env.getProperty("API.BOOKING_ADDSUCCESSFUL");
			System.out.println(successmsg);

			ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
			
			return responsemsg;
		
			}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
			}
		
		
	}
	//===============UPDATE THEATRE==================================//
	@PostMapping(path="/updateTheatre")	
	public  ResponseEntity<String>  updateTheatre(@RequestBody Theatre theatre) throws Exception{
	
		try {
			String tname =theatreService.updateTheatre(theatre);
			String successmsg=tname+env.getProperty("API.UPDATED_SUCCESSFUL");

			ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
			return responsemsg;
			
		}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
			
		}
		
	}

	
	//====================DELETE THEATRE=====================================//
	
	@PostMapping(path="/deleteTheatre")	
	public ResponseEntity<String> deleteTheatre(@RequestBody Theatre theatre) throws Exception{

		try {
			String tname =theatreService.deleteTheatre(theatre);
			String successmsg=tname+env.getProperty("API.DELETED_SUCCESSFUL");

			ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
			return responsemsg;
			
			
		}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
			
		}
		
	}
	//======================GET ALL THEATRE LIST==================================//
	@GetMapping(path="/getAllTheatreDetails")	
	public  ResponseEntity<List<Theatre>> getAllTheatrerDetails() throws Exception{
		
	
		try {

			List<Theatre> theatreList=new ArrayList<Theatre>();
			theatreList=theatreService.getAllTheatreDetails();
			
			return new ResponseEntity<List<Theatre>>(theatreList,HttpStatus.OK);

		}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
			}
	}

	
	
	

}
