package com.theatre.service;

import java.util.List;

import org.json.simple.JSONObject;

import com.theatre.model.Theatre;

public interface TheatreService {
	public String addTheatre(Theatre theatre) throws Exception;
	public String updateTheatre(Theatre theatre) throws Exception;
	public String deleteTheatre(Theatre theatre) throws Exception;
	public List<Theatre> getAllTheatreDetails() throws Exception;
}
