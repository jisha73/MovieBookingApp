package com.theatre.service;

import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.theatre.dao.TheatreDAO;
import com.theatre.model.Theatre;




@Service(value="theatreService")
@Transactional

public class TheatreServiceImpl implements TheatreService{
	@Autowired
	private TheatreDAO theatreDAO;
	@Autowired
	private Environment environment;
	//===============================ADD THEATRE===============================//
	public String addTheatre(Theatre theatre) throws Exception{
		
			
		String message=theatreDAO.addTheatre(theatre);
		if(message==null) {
			throw new Exception("Service.THEATRE_ALREADY_EXISTS");
		}
			return message;
	
				
}
	
	
	//===============================UPDATE THEATRE===============================//
	
	
	public String updateTheatre(Theatre theatre) throws Exception{
		
			
			String value=theatreDAO.updateTheatre(theatre);
				if(value!=null) {
					String uname=theatre.getTheatreName();
					return uname;
				}

				
				else {
					throw new Exception("Service.THEATRE_CANT_BE_UPDATED");
				}
			
			
		}

	//===============================DELETE THEATRE================================//
	
	public String deleteTheatre(Theatre theatre) throws Exception{
		
	
			
			String value=theatreDAO.deleteUser(theatre);
				if(value!=null) {
				
					String uname=theatre.getTheatreName();
					return uname;
				
				}
				else {
					throw new Exception("Service.THEATRE_CANT_BE_DELETED");
				}
			
		
	
	}
	//==================================GET THEATRE LIST=====================================//
	public List<Theatre> getAllTheatreDetails() throws Exception{

		List<Theatre> listTheatre=theatreDAO.getAllTheatreDetails();
		if(listTheatre.isEmpty()) {
			throw new Exception("Service.NO_THEATRE_DETAILS_FOUND");
		}
		return listTheatre;
}
}