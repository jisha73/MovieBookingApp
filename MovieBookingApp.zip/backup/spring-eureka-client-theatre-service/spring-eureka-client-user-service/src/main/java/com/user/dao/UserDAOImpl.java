package com.user.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.user.entity.UserEntity;
import com.user.model.User;

@Repository(value="userDAO")
public class UserDAOImpl implements UserDAO{

	
	@PersistenceContext
	private EntityManager entityManager;

	
//========================LOGIN==============================//
@Override
public User getUser(String userName,String password) throws Exception{
		User user= null;
Query q= entityManager.createQuery("select u from UserEntity u where u.userName=?1 and u.password=?2" );
q.setParameter(1, userName);
q.setParameter(2, password);
List <UserEntity> entityList=q.getResultList();

				if(entityList.isEmpty()) 
					return null;
				UserEntity usrentity=entityList.get(0);
				if( entityList!=null) {
					user = new User();
					user.setUserName( usrentity.getUserName());
					user.setPassword( usrentity.getPassword());
					user.setUserMailid(usrentity.getUserMailid());
					user.setPhoneNo(usrentity.getPhoneNo());
					user.setRole(usrentity.getRole());
					return user;
				}
				
				return null;	
					
		}

//========================REGISTER USER==============================//
@Override
public String registerUser(User user) throws Exception {
	UserEntity userentity=entityManager.find(UserEntity.class, user.getUserName());
	if(userentity!=null) {
		return null;
	}
		UserEntity userEntity1= new UserEntity();		
		userEntity1.setUserMailid(user.getUserMailid());
		userEntity1.setPhoneNo(user.getPhoneNo());
		userEntity1.setRole(user.getRole());
		userEntity1.setPassword(user.getPassword());
		userEntity1.setUserName(user.getUserName());
		entityManager.persist(userEntity1);
return user.getUserName();
	

}}