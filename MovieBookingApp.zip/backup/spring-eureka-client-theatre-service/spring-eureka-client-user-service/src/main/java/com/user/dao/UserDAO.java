package com.user.dao;

import com.user.model.User;

public interface UserDAO {
	public User getUser(String userName,String password) throws Exception;
	public String registerUser(User user) throws Exception;
//	public User getUser1(String userName) throws Exception;
}
