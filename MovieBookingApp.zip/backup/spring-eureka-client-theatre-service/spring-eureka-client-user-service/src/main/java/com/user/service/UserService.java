package com.user.service;

import org.json.simple.JSONObject;

import com.user.model.User;

public interface UserService {
	public User getLogin(String userName,String password) throws Exception;
	public String registerUser(User user) throws Exception;

}
