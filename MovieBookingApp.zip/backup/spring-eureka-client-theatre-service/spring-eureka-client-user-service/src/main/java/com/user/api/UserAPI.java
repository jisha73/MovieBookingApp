package com.user.api;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.user.model.User;
import com.user.service.UserService;




@RestController
@CrossOrigin
@RequestMapping(value="/userDetails")
public class UserAPI {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private Environment env;
	//================LOGIN USER=================//
	@PostMapping(value="/login")
	public ResponseEntity<User> getLogin(@RequestBody User user) throws Exception {
		
		try {

			User usr=userService.getLogin(user.getUserName(),user.getPassword());
			return new ResponseEntity<User>(usr,HttpStatus.OK);
			}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg,e);

	
	
			}
		
		}
	
	//===================REGISTER USER===========//
	@PostMapping(path="/registerUser")	
	public ResponseEntity<String>  registerUser(@RequestBody User user) throws Exception{
		
		try {
			String message=userService.registerUser(user);
			
			String successmsg=message+env.getProperty("API.BOOKING_ADDSUCCESSFUL");
			System.out.println(successmsg);

			ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
			
					return responsemsg;
			}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
			}
		
	}


}

	
