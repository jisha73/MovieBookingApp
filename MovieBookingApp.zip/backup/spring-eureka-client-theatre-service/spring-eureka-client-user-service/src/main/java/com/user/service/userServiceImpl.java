package com.user.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.user.dao.UserDAO;
import com.user.model.User;
@Service(value="userLoginService")
@Transactional

public class userServiceImpl implements UserService {
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private Environment env;

//================LOGIN============================//
@Override
public User getLogin(String userName,String password) throws Exception{
		User credentials=userDAO.getUser(userName,password);
		if(credentials== null) {
		throw new Exception("API.INVALID_CREDENTIALS");
		
	}
	return credentials;
	
}

		
	//================REGISTER USER============================//
	public String registerUser(User user) throws Exception{
	
		String message=userDAO.registerUser(user);
		if(message==null) {
			throw new Exception("API.USERALREDY_EXIST");
		}
			return message;
	
				
}

}

