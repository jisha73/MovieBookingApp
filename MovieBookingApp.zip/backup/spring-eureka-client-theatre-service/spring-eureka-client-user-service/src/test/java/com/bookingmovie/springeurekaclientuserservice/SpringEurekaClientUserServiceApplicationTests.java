package com.bookingmovie.springeurekaclientuserservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEurekaClientUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
