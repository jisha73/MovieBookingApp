package com.bookingmovie.springeurekaclientbookingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEurekaClientBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
