package com.booking.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="theatre")
public class TheatreEntity {

	
		@Id
		@Column(name = "theatre_name")
		String theatreName;
		@Column(nullable = false)
		String location;
		@Column(name = "seating_capacity", nullable = false)
		Integer seatingCapacity;
		Integer price;
		public String getTheatreName() {
			return theatreName;
		}
		public void setTheatreName(String theatreName) {
			this.theatreName = theatreName;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public Integer getSeatingCapacity() {
			return seatingCapacity;
		}
		public void setSeatingCapacity(Integer seatingCapacity) {
			this.seatingCapacity = seatingCapacity;
		}
		public Integer getPrice() {
			return price;
		}
		public void setPrice(Integer price) {
			this.price = price;
		}

		
}