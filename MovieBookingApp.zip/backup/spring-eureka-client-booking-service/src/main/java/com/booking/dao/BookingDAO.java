package com.booking.dao;

import java.util.Date;
import java.util.List;

import com.booking.model.Booking;
import com.booking.model.Report;

public interface BookingDAO {
	public String addBooking(Booking booking) throws Exception;
	public String cancelBooking(Booking booking) throws Exception;
	public List<Booking> getAllBookDetails(String userName) throws Exception;
	public List<Report> getAllReportDetails() throws Exception;
}
