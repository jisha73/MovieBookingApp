package com.booking.model;



public class Report {
private Integer reportId;
private Integer bookingId;
private Integer noOfTickets;
private String date;
private String time;
private String status;
public Integer getReportId() {
	return reportId;
}
public void setReportId(Integer reportId) {
	this.reportId = reportId;
}
public Integer getBookingId() {
	return bookingId;
}
public void setBookingId(Integer bookingId) {
	this.bookingId = bookingId;
}
public Integer getNoOfTickets() {
	return noOfTickets;
}
public void setNoOfTickets(Integer noOfTickets) {
	this.noOfTickets = noOfTickets;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
}
