package com.booking.model;

public class Show {
	private Integer showId;	
	private String showTime;
	private String showAvailableFrom;
	private String movieName;
	private String theatreName;
	private Integer remainingSeats;
	public Integer getRemainingSeats() {
		return remainingSeats;
	}
	public void setRemainingSeats(Integer remainingSeats) {
		this.remainingSeats = remainingSeats;
	}
	public Integer getShowId() {
		return showId;
	}
	public void setShowId(Integer showId) {
		this.showId = showId;
	}
	public String getShowTime() {
		return showTime;
	}
	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}
	public String getShowAvailableFrom() {
		return showAvailableFrom;
	}
	public void setShowAvailableFrom(String showAvailableFrom) {
		this.showAvailableFrom = showAvailableFrom;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
}
