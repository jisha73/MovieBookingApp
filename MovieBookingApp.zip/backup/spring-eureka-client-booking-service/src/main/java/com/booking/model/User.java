package com.booking.model;

public class User {

	//private String userId;
	private String userName;
	private String password;
	private long phoneNo;
	private String role;
	private String userMailid;

//	public String getUserId() {
//		return userId;
//	}
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUserMailid() {
		return userMailid;
	}
	public void setUserMailid(String userMailid) {
		this.userMailid = userMailid;
	}

}