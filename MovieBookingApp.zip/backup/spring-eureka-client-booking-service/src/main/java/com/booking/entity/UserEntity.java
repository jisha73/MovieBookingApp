package com.booking.entity;

import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="user")
public class UserEntity {	
	@Id
	
	@Column(name = "user_name",nullable = false, length = 50)
	String userName;
	@Column(nullable = false)
	String password;
	@Column(name = "phone_no", nullable = false)
	Long phoneNo;
	@Column(name="user_mailid",nullable = false, length = 50)
	String userMailid;
	
	@Column(nullable = false, length = 1)
	String role;

//	public String getUserId() {
//		return userId;
//	}
//
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getUserMailid() {
		return userMailid;
	}

	public void setUserMailid(String userMailid) {
		this.userMailid = userMailid;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}