package com.booking.service;

import java.util.Date;
import java.util.List;

import com.booking.model.Booking;
import com.booking.model.Report;
import com.booking.model.User;

public interface BookingService {
	public String bookMovie(Booking booking) throws Exception;
	public String cancelTicket(Booking booking) throws Exception;

	public List<Booking> getAllBookDetails(String userName) throws Exception;
	public List<Report> getAllReportDetails() throws Exception;
}
