package com.booking.api;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.booking.model.Booking;
import com.booking.model.Report;
import com.booking.service.BookingService;



@RestController
@CrossOrigin
@RequestMapping(value="/bookingDetails")

public class BookingAPI {

		@Autowired
		private BookingService bookingService;
		@Autowired
		private Environment env;
		//=============================BOOK TICKETS==========================================//
		@PostMapping(path="/booktickets")	
		public ResponseEntity<String> bookMovie(@RequestBody Booking booking) throws Exception{
			
			
			try {
				String message= bookingService.bookMovie(booking);
				
				String successmsg=env.getProperty("API.BOOKING_ADDSUCCESSFUL");
				System.out.println(successmsg);

				ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
				
				return responsemsg;
			
				}
			catch(Exception e) {
				String msg=env.getProperty(e.getMessage());
				System.out.println(msg);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
				}
			
			
		}
		//============================CANCEL BOOKING=======================================//
		
		@PostMapping(path="/canceltickets")	
		public ResponseEntity<String> cancelTickets(@RequestBody Booking booking) throws Exception{

			try {
				String tname =bookingService.cancelTicket(booking);
				String successmsg=env.getProperty("API.CANCEL_SUCCESSFUL");

				ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
				return responsemsg;
				
				
			}
			catch(Exception e) {
				String msg=env.getProperty(e.getMessage());
				System.out.println(msg);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
				
			}}
		
		

		//======================================get booking by username===================================================//
		
		@GetMapping(path="/getAllbookDetails/{userName}")	
		public  ResponseEntity<List<Booking>> getAllbookDetails(@PathVariable String userName)throws Exception{
			
		
			try {
			
				List<Booking> bookList=new ArrayList<Booking>();
				bookList=bookingService.getAllBookDetails(userName);
				
				return new ResponseEntity<List<Booking>>(bookList,HttpStatus.OK);

			}
			catch(Exception e) {
				String msg=env.getProperty(e.getMessage());
				System.out.println(msg);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
				}
		}
		
		//=================================get all reports===============================================//
		@GetMapping(path="/getAllreportDetails")	
		public  ResponseEntity<List<Report>> getAllreportDetails()throws Exception{
			
		
			try {
			
				List<Report> bookList=new ArrayList<Report>();
				bookList=bookingService.getAllReportDetails();
				
				return new ResponseEntity<List<Report>>(bookList,HttpStatus.OK);

			}
			catch(Exception e) {
				String msg=env.getProperty(e.getMessage());
				System.out.println(msg);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
				}
		}
		
}
