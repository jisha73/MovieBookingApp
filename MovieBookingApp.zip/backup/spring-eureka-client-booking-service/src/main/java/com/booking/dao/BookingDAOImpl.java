package com.booking.dao;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.booking.entity.BookingEntity;
import com.booking.entity.ReportEntity;
import com.booking.entity.ShowEntity;
import com.booking.model.Booking;
import com.booking.model.Report;


@Repository(value="bookingDAO")

public class BookingDAOImpl implements BookingDAO {
	@PersistenceContext
	private EntityManager entityManager;
	
	//=================================BOOK TICKETS=========================================//
	@Override
	public String addBooking(Booking booking) throws Exception{
		
		String q="select d from ShowEntity d where d.showTime=?1 and d.theatreName=?2 and d.movieName=?3";
		Query query1=entityManager.createQuery(q);
		query1.setParameter(1,booking.getShowTime());
		query1.setParameter(2,booking.getTheatreName());
		query1.setParameter(3,booking.getMovieName());
		List<ShowEntity> booklist=query1.getResultList();
		ShowEntity showrow = booklist.get(0);
		System.out.println(showrow);
		System.out.println(showrow.getMovieName());
		System.out.println(showrow.getRemainingSeats());
		System.out.println(booking.getNoOfTickets());
		if( showrow.getRemainingSeats()<booking.getNoOfTickets()) {
			return "full";
		}
		Integer seats=showrow.getRemainingSeats();
		Integer remainingSeats=seats-booking.getNoOfTickets();
		showrow.setRemainingSeats(remainingSeats);
		System.out.println(remainingSeats);
		System.out.println(showrow.getRemainingSeats());
		System.out.println(remainingSeats);
			if(!booklist.isEmpty() && remainingSeats>0 && remainingSeats>booking.getNoOfTickets()) {
			BookingEntity bookingEntity1= new BookingEntity();
			bookingEntity1.setMovieName(booking.getMovieName());
			bookingEntity1.setTheatreName(booking.getTheatreName());
			bookingEntity1.setShowTime(booking.getShowTime());
			bookingEntity1.setNoOfTickets(booking.getNoOfTickets());
			bookingEntity1.setUserName(booking.getUserName());
			bookingEntity1.setBookingDate(booking.getBookingDate());
			Query query = entityManager.createQuery("select a.price from TheatreEntity a where a.theatreName=:theatreName");
			query.setParameter("theatreName",booking.getTheatreName());
			Integer price=(Integer)query.getSingleResult();
			System.out.println(price);
			Integer totalPrice=booking.getNoOfTickets()*price;
			bookingEntity1.setTotalPrice(totalPrice);
			System.out.println(totalPrice);
			entityManager.persist(bookingEntity1);
			System.out.println(bookingEntity1.getTotalPrice());
			System.out.println(bookingEntity1.getBookingId());
			
			ReportEntity reportEntity=new ReportEntity();
			reportEntity.setBookingId(bookingEntity1.getBookingId());
			System.out.println(bookingEntity1.getBookingId());
			reportEntity.setDate(bookingEntity1.getBookingDate());
			reportEntity.setNoOfTickets(bookingEntity1.getNoOfTickets());
			reportEntity.setTime(bookingEntity1.getShowTime());
			
			reportEntity.setStatus("BOOKED");
			entityManager.persist(reportEntity);
			return "sucess";
			}
			
	return null;
		
	}
	//=====================================CANCEL TICKETS=======================================//
	@Override
	public String cancelBooking(Booking booking) throws Exception {
		BookingEntity bookingEntity= entityManager.find(BookingEntity.class, booking.getBookingId());
		System.out.println(bookingEntity.getShowTime());
		if(	bookingEntity!=null)  {
		System.out.println(bookingEntity.getBookingId());
		
		String q="select d from ShowEntity d where d.showTime=?1 and d.theatreName=?2 and d.movieName=?3";
		Query query1=entityManager.createQuery(q);
		System.out.println("hkhjk");
		query1.setParameter(1,bookingEntity.getShowTime());
		query1.setParameter(2,bookingEntity.getTheatreName());
		query1.setParameter(3,bookingEntity.getMovieName());
		System.out.println("ss");
		List<ShowEntity> booklist1=query1.getResultList();
		System.out.println(booklist1);
		ShowEntity showrow = booklist1.get(0);
		System.out.println("ss");
//		Query query2 = entityManager.createQuery("select d.remainingSeats  from ShowEntity d where d.showTime=?1 and d.theatreName=?2 and d.movieName?3");
//		query2.setParameter(1,booking.getShowTime());
//		query2.setParameter(2,booking.getTheatreName());
//		query2.setParameter(3,booking.getMovieName());
//		Integer seats=(Integer)query2.getSingleResult();
		Integer remainingSeats=showrow.getRemainingSeats()+bookingEntity.getNoOfTickets();
		showrow.setRemainingSeats(remainingSeats);
		System.out.println(showrow.getRemainingSeats());
//		
	
	
		

				
				
				Query query3 = entityManager.createQuery("select a from ReportEntity a where a.bookingId=:bookingId");
				query3.setParameter("bookingId",booking.getBookingId());
				List<ReportEntity >booklist3=query3.getResultList();
				ReportEntity reportrow=booklist3.get(0);
				reportrow.setStatus("CANCEL");
				
				Query query = entityManager.createQuery("select a from BookingEntity a where a.bookingId=:bookingId");
				query.setParameter("bookingId",bookingEntity.getBookingId());
						List<BookingEntity>booklist=query.getResultList();
						System.out.println("ss"+booklist);
						for(BookingEntity  a: booklist) {
						a.setBookingId(null);
						a.setBookingDate(null);
						a.setMovieName(null);
						a.setNoOfTickets(null);
						a.setShowTime(null);
						a.setTheatreName(null);
						a.setTotalPrice(null);
						a.setUserName(null);}
						entityManager.remove(bookingEntity);
						System.out.println(bookingEntity.getBookingDate());
				return "success";
				
				
			}return null;
			}

	//======================================get booking===================================================//
	@Override
	public List<Booking> getAllBookDetails(String userName) throws Exception{
	
			List<Booking> finalbook = new ArrayList<Booking>();
			System.out.println(userName);
			Query query = entityManager.createQuery("select u from BookingEntity u where u.userName=:userName");
			query.setParameter("userName", userName);
		
			List<BookingEntity> bookList = query.getResultList();
			System.out.println(bookList);
			if(bookList != null) {
				for(BookingEntity bookEntity: bookList) {
					Booking booking= new Booking();
					booking.setBookingDate(bookEntity.getBookingDate());
					booking.setBookingId(bookEntity.getBookingId());
					booking.setMovieName(bookEntity.getMovieName());
					booking.setNoOfTickets(bookEntity.getNoOfTickets());
					booking.setTheatreName(bookEntity.getTheatreName());
					booking.setTotalPrice(bookEntity.getTotalPrice());
					booking.setUserName(bookEntity.getUserName());
					booking.setShowTime(bookEntity.getShowTime());
					finalbook.add(booking);
				}
			}return finalbook;}
	//======================================get booking===================================================//
	@Override
	public List<Report> getAllReportDetails() throws Exception{
	
		List<Report> finalreport = new ArrayList<Report>();
//DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd-MM-yyyy");
//LocalDate date1=LocalDate.parse(startDate,formatter1);
//DateTimeFormatter formatter2=DateTimeFormatter.ofPattern("dd-MM-yyyy");
//LocalDate date2=LocalDate.parse(endDate,formatter2);
//System.out.println(date1);
//System.out.println(date2);

			Query query = entityManager.createQuery("select u from ReportEntity u ");
			
			List<ReportEntity> reportList = query.getResultList();
			System.out.println(reportList.get(0).getDate());
			
			if(reportList != null) {
				for(ReportEntity reportEntity:reportList) {
					Report report= new Report();
					report.setBookingId(reportEntity.getBookingId());
					report.setDate(reportEntity.getDate());
					report.setNoOfTickets(reportEntity.getNoOfTickets());
					report.setReportId(reportEntity.getReportId());
					report.setStatus(reportEntity.getStatus());
					report.setTime(reportEntity.getTime());
				
					finalreport.add(report);
				}
			}return finalreport;}
}
