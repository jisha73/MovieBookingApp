package com.booking.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.booking.dao.BookingDAO;
import com.booking.model.Booking;
import com.booking.model.Report;
import com.booking.model.User;

@Service(value="bookingService")
@Transactional

public class BookingServiceImpl implements BookingService {
	
	
	@Autowired
	BookingDAO bookingDAO;
	//=================================BOOK TICKETS=========================================//
public String bookMovie(Booking booking) throws Exception{
		
		
		
		String message= bookingDAO.addBooking(booking);
		if(message==null) {
			throw new Exception("Service.BOOK_ALREADY_EXISTS");
		}
		if(message.equals("full")) {
			throw new Exception("Service.BOOK_FULL");
		}
	
			return message;
	
				
}
	
	//=====================================CANCEL TICKETS=======================================//
public String cancelTicket(Booking booking) throws Exception{
	
	
	
	String value=bookingDAO.cancelBooking(booking);
		if(value!=null) {
		
			
			return value;
		
		}
		else {
			throw new Exception("Service.BOOKING_CANT_BE_DELETED");
		}
	

}


//======================================get booking===================================================//

public List<Booking> getAllBookDetails(String userName) throws Exception{

	List<Booking> listMovie=bookingDAO.getAllBookDetails(userName);
	if( listMovie.isEmpty()) {
		throw new Exception("Service.NO_BOOK_DETAILS_FOUND");
	}
	  return listMovie;
	}

//======================================get report===================================================//
public List<Report> getAllReportDetails() throws Exception{

	List<Report> listMovie=bookingDAO.getAllReportDetails();
	if( listMovie.isEmpty()) {
		throw new Exception("Service.NO_REPORT_DETAILS_FOUND");
	}
	  return listMovie;
	}
}
