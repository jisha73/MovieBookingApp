package com.movie.service;

import java.util.List;


import com.movie.model.Movie;
import com.movie.model.Show;

public interface MovieService {
	public String addMovie(Movie movie) throws Exception;
	public String updateMovie(Movie movie) throws Exception;
	public String deleteMovie(Movie movie) throws Exception;
	public List<Movie> getAllMovieDetails() throws Exception;
	public String addShow(Show show) throws Exception;
	public String deleteShow(Show show) throws Exception;
	public List<Show> getAllShowDetails() throws Exception;
}
