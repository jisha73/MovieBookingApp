package com.movie.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="shows")
public class ShowEntity {
	@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

	@Column(name = "show_id")
	Integer showId;	
	@Column(name = "show_time")
	String showTime;
	
	@Column(name = "show_available_from")
	String showAvailableFrom;
	@Column(name = "remaining_seats")
	Integer remainingSeats;
//	@Column(name = "movie_name")
//	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="movie_name")
	
	String movieName;
//	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="theatre_name")
	String theatreName;
public Integer getRemainingSeats() {
		return remainingSeats;
	}
	public void setRemainingSeats(Integer remainingSeats) {
		this.remainingSeats = remainingSeats;
	}
	
	public Integer getShowId() {
		return showId;
	}
	public void setShowId(Integer showId) {
		this.showId = showId;
	}
	public String getShowTime() {
		return showTime;
	}
	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}
	public String getShowAvailableFrom() {
		return showAvailableFrom;
	}
	public void setShowAvailableFrom(String showAvailableFrom) {
		this.showAvailableFrom = showAvailableFrom;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	
}
