package com.movie.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.aspectj.weaver.ast.And;
import org.springframework.stereotype.Repository;

import com.movie.entity.BookingEntity;
import com.movie.entity.MovieEntity;
import com.movie.entity.ShowEntity;
import com.movie.entity.TheatreEntity;
import com.movie.model.Movie;
import com.movie.model.Show;


@Repository(value="movieDAO")
public class MovieDAOImpl implements MovieDAO {

	@PersistenceContext
	private EntityManager entityManager;
	//===========================ADD MOVIE===========================================//
	@Override
	public String addMovie(Movie movie) throws Exception{
		
	
		MovieEntity movieEntity= entityManager.find(MovieEntity.class, movie.getMovieName());
			if(movieEntity!=null) {
				return null;}
			MovieEntity movieEntity1= new MovieEntity();
			movieEntity1.setMovieName(movie.getMovieName());
			movieEntity1.setCategory(movie.getCategory());
			movieEntity1.setLanguage(movie.getLanguage());
			movieEntity1.setDirector(movie.getDirector());
			
			entityManager.persist(movieEntity1);
			return movie.getMovieName();
	
		
	}
	//===========================UPDATE MOVIE===========================================//
	@Override
	public String updateMovie(Movie movie) throws Exception{

		MovieEntity movieEntity= entityManager.find(MovieEntity.class, movie.getMovieName());
			if(movieEntity==null)  {
				return null;
			}
			
			movieEntity.setCategory(movie.getCategory());
			movieEntity.setDirector(movie.getDirector());
			movieEntity.setLanguage(movie.getLanguage());
		  	Query query = entityManager.createQuery("select a from MovieEntity a where a.movieName=:movieName");
				query.setParameter("movieName",movieEntity.getMovieName());
				List<	MovieEntity > movielist=query.getResultList();
				for(MovieEntity  a: movielist) {
				a.setCategory(movieEntity.getCategory());
				a.setDirector(movieEntity.getDirector());
				a.setLanguage(movieEntity.getLanguage());
				
					return movie.getMovieName();
				}return null;
	}
	//===========================DELETE MOVIE===========================================//
	@Override
	public String deleteMovie(Movie movie) throws Exception {
		
		MovieEntity movieEntity= entityManager.find(MovieEntity.class, movie.getMovieName());
//		ShowEntity showEntity= entityManager.find(ShowEntity.class,movie.getMovieName());
System.out.println(movieEntity.getMovieName());
		String q="select d from ShowEntity d where d.movieName=?1";
		Query query1=entityManager.createQuery(q);
		query1.setParameter(1,movie.getMovieName());
	
		List<ShowEntity> showlist=query1.getResultList();
		System.out.println(showlist.size());
			if(	movieEntity!=null && showlist.size()==0)  {
				Query query = entityManager.createQuery("select a from MovieEntity a where a.movieName=:movieName");
				query.setParameter("movieName",movieEntity.getMovieName());
				List<MovieEntity > movielist=query.getResultList();
				for(MovieEntity  a: movielist) {
					a.setCategory(null);
					a.setDirector(null);
					a.setLanguage(null);
					a.setMovieName(null);
				}
					
				entityManager.remove(movieEntity);
				return movie.getMovieName();
				}
				return null;
		
		}
	
	//===========================GET ALL MOVIE===========================================//
	@Override
	public List<Movie> getAllMovieDetails() throws Exception{
	
			List<Movie> finalmovie = new ArrayList<Movie>();
			Query query = entityManager.createQuery("select u from MovieEntity u");
			List<MovieEntity> movieList = query.getResultList();
			if(movieList != null) {
				for(MovieEntity movieEntity: movieList) {
					Movie movie= new Movie();
					movie.setMovieName(movieEntity.getMovieName());
					movie.setCategory(movieEntity.getCategory());
					movie.setLanguage(movieEntity.getLanguage());
					movie.setDirector(movieEntity.getDirector());
					finalmovie.add(movie);
				}
			}return finalmovie;}
	//===========================ADD SHOW===========================================//
	
	@Override
	public Boolean addShow(Show show) throws Exception{
	
		
		String q="select d from ShowEntity d where d.showTime=?1 and d.theatreName=?2";
		Query query1=entityManager.createQuery(q);
		query1.setParameter(1,show.getShowTime());
		query1.setParameter(2,show.getTheatreName());
		List<ShowEntity> showlist=query1.getResultList();
	
		if(showlist.isEmpty()) {
			ShowEntity showEntity1= new ShowEntity();
			showEntity1.setShowTime(show.getShowTime());
			showEntity1.setShowAvailableFrom(show.getShowAvailableFrom());
			showEntity1.setMovieName(show.getMovieName());
			showEntity1.setTheatreName(show.getTheatreName());
			showEntity1.setRemainingSeats(show.getRemainingSeats());
			Query query = entityManager.createQuery("select a.seatingCapacity from TheatreEntity a where a.theatreName=:theatreName");
			query.setParameter("theatreName",show.getTheatreName());
			Integer seat=(Integer)query.getSingleResult();
			showEntity1.setRemainingSeats(seat);
			entityManager.persist(showEntity1);
		

			return true;
		}return false;

		

	
		
		
	
		
	}

	//===========================DELETE SHOW===========================================//
	@Override
	public Boolean deleteShow(Show show) throws Exception {
		
		ShowEntity showEntity= entityManager.find(ShowEntity.class, show.getShowId());
		
		System.out.println(showEntity.getMovieName());
		System.out.println(showEntity.getShowTime());
				Query query = entityManager.createQuery("select a from ShowEntity a where a.showId=:showId");
				query.setParameter("showId",showEntity.getShowId());
				List<ShowEntity > showlist=query.getResultList();
				System.out.println(showlist.size());
				System.out.println(showlist.get(0).getMovieName());
				Query query1 = entityManager.createQuery("select a from BookingEntity a where a.showTime=:showTime and a.theatreName=:theatreName and a.movieName=:movieName");
				query1.setParameter("showTime",showEntity.getShowTime());
				query1.setParameter("theatreName",showEntity.getTheatreName());
				query1.setParameter("movieName",showEntity.getMovieName());
				List<BookingEntity> booklist=query1.getResultList();
				System.out.println(booklist.size());
				System.out.println("dd");

				System.out.println(showlist.size());
				System.out.println(booklist.size());
				if(	showlist.size()!=0 && booklist.size()==0)  {
					System.out.println("rg");
				for(ShowEntity  a: showlist) {
					System.out.println("ss");
					a.setMovieName(null);
					a.setShowAvailableFrom(null);
					a.setShowId(null);
					a.setShowTime(null);
					a.setTheatreName(null);
					a.setRemainingSeats(null);
				}
					
				entityManager.remove(showEntity);
				return true;
				}
				return false;
		
		}
	//==========================GET ALL SHOWS===========================================//
	
	@Override
	public List<Show> getAllShowDetails() throws Exception{
	
			List<Show> finalshow = new ArrayList<Show>();
			Query query = entityManager.createQuery("select u from ShowEntity u");
			List<ShowEntity> showList = query.getResultList();
			if(showList != null) {
				for(ShowEntity showEntity: showList) {
					Show show= new Show();
					show.setShowId(showEntity.getShowId());
					show.setShowAvailableFrom(showEntity.getShowAvailableFrom());
					show.setShowTime(showEntity.getShowTime());
					show.setMovieName(showEntity.getMovieName());
					show.setTheatreName(showEntity.getTheatreName());
					show.setRemainingSeats(showEntity.getRemainingSeats());
					show.setRemainingSeats(showEntity.getRemainingSeats());
					finalshow.add(show);
				}
			}return finalshow;}
	
}
