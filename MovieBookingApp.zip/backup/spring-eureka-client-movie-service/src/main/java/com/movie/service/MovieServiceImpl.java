package com.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.movie.dao.MovieDAO;
import com.movie.model.Movie;
import com.movie.model.Show;


@Service(value="movieService")
@Transactional

public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieDAO movieDAO;
	@Autowired
	private Environment environment;
	
	
	//===========================ADD MOVIE===========================================//
	
	public String addMovie(Movie movie) throws Exception{
		
		
		String message= movieDAO.addMovie(movie);
		if(message==null) {
			throw new Exception("Service.MOVIE_ALREADY_EXISTS");
		}
			return message;
	
				
}
	//===========================UPDATE MOVIE===========================================//
	
	public String updateMovie(Movie movie) throws Exception{
		
		
		String value=movieDAO.updateMovie(movie);
			if(value!=null) {
				String uname=movie.getMovieName();
				return uname;
			}

			
			else {
				throw new Exception("Service.MOVIE_CANT_BE_UPDATED");
			}
		
		
	}
	//===========================DELETE MOVIE===========================================//
	public String deleteMovie(Movie movie) throws Exception{
		
		
		
		String value=movieDAO.deleteMovie(movie);
			if(value!=null) {
			
				String uname=movie.getMovieName();
				return uname;
			
			}
			else {
				throw new Exception("Service.MOVIE_CANT_BE_DELETED");
			}
		

}
	
	
	//===========================GET ALL MOVIE===========================================//

	public List<Movie> getAllMovieDetails() throws Exception{
		List<Movie> listMovie=movieDAO.getAllMovieDetails();
		if( listMovie.isEmpty()) {
			throw new Exception("Service.NO_MOVIE_DETAILS_FOUND");
		}
		return  listMovie;}

	//===========================ADD SHOW===========================================//
public String addShow(Show show) throws Exception{
		
		
		Boolean message= movieDAO.addShow(show);
		if(message==false) {
			throw new Exception("Service.SHOW_ALREADY_EXISTS");
		}
			return "sucess";
	
				
}

	//===========================DELETE SHOW===========================================//
public String deleteShow(Show show) throws Exception{
	
	
	
	Boolean value=movieDAO.deleteShow(show);
		if(value==true) {
		
			
			return "success";
		
		}
		else {
			throw new Exception("Service.MOVIE_CANT_BE_DELETED");
		}
	

}


	//==========================GET ALL SHOWS===========================================//
	
public List<Show> getAllShowDetails() throws Exception{

	List<Show> listShow=movieDAO.getAllShowDetails();
	if( listShow.isEmpty()) {
		throw new Exception("Service.NO_SHOW_DETAILS_FOUND");
	}
	return  listShow;}
	
}
