package com.movie.dao;

import java.util.List;

import com.movie.model.Movie;
import com.movie.model.Show;

public interface MovieDAO {

	public String addMovie(Movie movie) throws Exception;
	public String updateMovie(Movie movie) throws Exception;
	public String deleteMovie(Movie movie) throws Exception;
	public List<Movie> getAllMovieDetails() throws Exception;
	public Boolean addShow(Show show) throws Exception;
	public Boolean deleteShow(Show show) throws Exception;
	public List<Show> getAllShowDetails() throws Exception;
}
