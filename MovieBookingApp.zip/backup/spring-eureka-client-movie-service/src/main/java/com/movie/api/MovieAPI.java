package com.movie.api;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.movie.model.Movie;
import com.movie.model.Show;
import com.movie.service.MovieService;





@RestController
@CrossOrigin
@RequestMapping(value="/movieDetails")
public class MovieAPI {
	@Autowired
	private MovieService movieService;
	@Autowired
	private Environment env;
	//=======================ADD MOVIE===========================//
	
	
	@PostMapping(path="/addMovie")	
	public ResponseEntity<String> addMovie(@RequestBody Movie movie) throws Exception{
		
		
		try {
String message= movieService.addMovie(movie);
			
			String successmsg=message+env.getProperty("API.BOOKING_ADDSUCCESSFUL");
			System.out.println(successmsg);

			ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
			
			return responsemsg;
		
			}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
			}
		
		
	}
	//=======================UPDATE MOVIE========================//
	
	
	@PostMapping(path="/updateMovie")	
	public  ResponseEntity<String>  updateMovie(@RequestBody Movie movie) throws Exception{
	
		try {
			String mname =movieService.updateMovie(movie);
			String successmsg=mname+env.getProperty("API.UPDATED_SUCCESSFUL");

			ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
			return responsemsg;
			
		}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
			
		}
		
	}
	//=======================DELETE MOVIE========================//
	@PostMapping(path="/deleteMovie")	
	public ResponseEntity<String> deleteMovie(@RequestBody Movie movie) throws Exception{

		try {
			String tname =movieService.deleteMovie(movie);
			String successmsg=env.getProperty("API.DELETED_SUCCESSFUL");

			ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
			return responsemsg;
			
			
		}
		catch(Exception e) {
			String msg=env.getProperty(e.getMessage());
			System.out.println(msg);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
			
		}}
	
	//=======================GET ALL MOVIE======================//
		@GetMapping(path="/getAllMovieDetails")	
		public  ResponseEntity<List<Movie>> getAllMovieDetails() throws Exception{
			
		
			try {
			
				List<Movie> movieList=new ArrayList<Movie>();
				movieList=movieService.getAllMovieDetails();
				
				return new ResponseEntity<List<Movie>>(movieList,HttpStatus.OK);

			}
			catch(Exception e) {
				String msg=env.getProperty(e.getMessage());
				System.out.println(msg);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
				}
		}
	//========================ADD SHOW==============================//
		

		@PostMapping(path="/addShow")	
		public ResponseEntity<String> addShow(@RequestBody Show show) throws Exception{
			
			
			try {
				String message= movieService.addShow(show);
				
				String successmsg=env.getProperty("API.SHOW_ADDSUCCESSFUL");
				System.out.println(successmsg);

				ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
				
				return responsemsg;
			
				}
			catch(Exception e) {
				String msg=env.getProperty(e.getMessage());
				System.out.println(msg);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
				}
			
			
		}
		
	//=======================DELETE SHOW========================//
		@PostMapping(path="/deleteShow")	
		public ResponseEntity<String> deleteShow(@RequestBody Show show) throws Exception{

			try {
				String tname =movieService.deleteShow(show);
				String successmsg=env.getProperty("API.SHOWDELETED_SUCCESSFUL");

				ResponseEntity<String> responsemsg= new ResponseEntity<String>(successmsg,HttpStatus.OK);
				return responsemsg;
				
				
			}
			catch(Exception e) {
				String msg=env.getProperty(e.getMessage());
				System.out.println(msg);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
				
			}}
		
	//=======================GET ALL SHOW======================//
		@GetMapping(path="/getAllShowDetails")	
		public  ResponseEntity<List<Show>> getAllShowDetails() throws Exception{
			
		
			try {
			
				List<Show> showList=new ArrayList<Show>();
				showList=movieService.getAllShowDetails();
				
				return new ResponseEntity<List<Show>>(showList,HttpStatus.OK);

			}
			catch(Exception e) {
				String msg=env.getProperty(e.getMessage());
				System.out.println(msg);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,msg);
				}
		}
		
		
}
