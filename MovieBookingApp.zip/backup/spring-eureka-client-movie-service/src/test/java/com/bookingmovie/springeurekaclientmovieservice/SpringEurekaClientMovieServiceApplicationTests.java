package com.bookingmovie.springeurekaclientmovieservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEurekaClientMovieServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
